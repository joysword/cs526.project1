var searchData=
[
  ['update',['update',['../classwandaid_1_1wandaid.html#aaed47ab1f76ead2d57dd5d0c33c73697',1,'wandaid::wandaid']]]
];
