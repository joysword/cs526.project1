var searchData=
[
  ['init',['init',['../classwandaid_1_1wandaid.html#af8dcd3b078761efeacbbf67471d9666e',1,'wandaid::wandaid']]]
];
