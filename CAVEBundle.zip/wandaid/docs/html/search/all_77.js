var searchData=
[
  ['wandaid',['wandaid',['../classwandaid_1_1wandaid.html',1,'wandaid']]],
  ['wandaid',['wandaid',['../namespacewandaid.html',1,'']]]
];
